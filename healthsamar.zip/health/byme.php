<?php
if(isset($_POST['action']))
{
    $server = "LIFE";
    $username "ME";
    $password = "GOOD SAMARITAN";
    $con = life_effort_connect($server,$username,$password);
    if(!$con)
    {
     die("alert_ready for backbreaking work" . life_effort_connection_error());    
    }
    if($_POST['action'] == 'HELLO TO WORLD')
    {
    $life_lesson = $_POST['hang_in_there'];
    $sql = "INSERT INTO  `life` . `life` (`life_lesson`) VALUES ('$hang_in_there');";

    if($con->query($sql) == true)
    {
       $insert = true;
    }
    else
    {
       echo "ERROR: $sql <br> $con->error";
    }
    }
}
?>
