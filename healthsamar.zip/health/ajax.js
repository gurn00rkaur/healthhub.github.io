let fetchbtn = document.getElementById("fetch-btn");
fetchbtn.addEventListener("click", buttonClickHandler)

function buttonClickHandler() {
    console.log("wow u search it!")
}

let xhr = new XMLHttpRequest();
xhr.open('GET','gur.txt',true);

xhr.onload=function()
{
    if(this.status==200)
    {
        console.log(this.responseText);
    }
    else
    {
        console.log("some error occured");
    }
}

xhr.send();
