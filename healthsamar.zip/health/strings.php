<?php
    $str = "this is string";
    echo $str;
    $lenn = strlen($str);
    echo "the length of a string is";
    echo $lenn;


    echo "the length of a string is" .$lenn ."ufff";
    // concatenate

    echo "the number of words in string is" . str_word_count($str);
    // count the number of words

    echo "the reverse of a string is" . strrev($str);
    // reverse of string is 

    echo "the position for word in the string is" . strpos($str, "word");
    // to find the position of string 

    echo "the replaced string is" .str_replace("word","words",$str);
    // to replace the word 


?>