<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        this is my first php website
    <!-- open source scripting language -->
    <?php
    echo "hello i have started learning php";
    $var1=34;
    $var2=45;
    echo $var1
    echo $var2;
    echo $var1+$var2;

    // operators
// arithmetic
echo "the value of var1+var2";
echo "<br>";
echo $var1+var2;
// assignment
// comparison
// increement
// logiocal
// descreement
    ?>
    </div>
</body>
</html>