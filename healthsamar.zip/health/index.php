<?php
echo "hello world";
echo "started learning php finally" ;

?>