<?php
$insert = false;

if(isset($_POST['action']))
{


// set connection variables
   $server = "localhost";
   $username = "root";
   $password = "";

   // create a database connection 
   $con = mysqli_connect($server,$username,$password);

   // check for connection success 
   if(!$con)
   {
    die("connection to this database failed due to" . mysqli_connect_error());    
   }
   // echo "success connecting to the db";


   if($_POST['action'] == 'save_patient')
{
    echo "THANK YOU";
   // collect post variables patient table
   $P_id = $_POST['P_id'];
   $name = $_POST['name'];
   $age = $_POST['age'];
   $gender = $_POST['gender'];
   $email = $_POST['email'];
   $mobileno = $_POST['mobileno'];
   $sql = "INSERT INTO  `healthcare` . `health` (`P_id`,`name`, `age`, `gender`, `email`, `mobileno`) VALUES ('$P_id','$name', '$age', '$gender', '$email', '$mobileno');";

   // echo $sql;

   // execute the query 
   if($con->query($sql) == true)
   {
      // echo "successfully inserted";

      // flag for sucessful insertion 
      $insert = true;
   }
   else
   {
      echo "ERROR: $sql <br> $con->error";
   }
}
    // close tha database connection 
    // $con->close();

    if($_POST['action'] == 'save_appointment')
    {
    // collect post variables appointment table
    echo "THANK YOU";

    $appointmentnum = $_POST['appointmentnum'];
    $P_id = $_POST['P_id'];
    $D_id = $_POST['D_id'];
    $date = $_POST['date'];
    $sql = "INSERT INTO `healthcare` . `appointment` (`appointmentnum`,`P_id`,`D_id`,`date`) VALUES ('$appointmentnum','$P_id','$D_id','$date');";

    // execute the query 
    if($con->query($sql) == true)
    {
        $insert = true;
    }
    else
    {
       echo "ERROR: $sql <br> $con->error";
    }
}
    
    // INSERT INTO `appointment` (`P_id`, `D_id`, `date`) VALUES ('957', '2105', '07-06-2023');
   
    // collect post variables doctor table
 
    if($_POST['action'] == 'save_doctor')
    {
        // print_r($_POST);
        echo "THANK YOU";

    $D_id = $_POST['D_id'];
    $D_name = $_POST['D_name'];
    $D_no = $_POST['D_no'];
    $sql = "INSERT INTO `healthcare` . `doctor` (`D_id`, `D_name`, `D_no`) VALUES ('$D_id', '$D_name', '$D_no');";

    // -- execute the query 
   if($con->query($sql) == true)
   {
      // echo "successfully inserted";

      // flag for sucessful insertion 
      $insert = true;
   }
   else
   {
      echo "ERROR: $sql <br> $con->error";
   }


//    INSERT INTO `doctor` (`D_id`, `D_name`, `D_no`) VALUES ('2105', 'Dr.Sanjeev Arora', '1981494910');

   // close tha database connection 
  
}
   $con->close();
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>website</title>
    <link rel="stylesheet" href="bk_h.css">
    <script src="h.js"></script>
</head>
<body>
    <!-- <div class="log"><a href="log.html">LOG-IN</a></div> -->
    <!-- <div class="sig"><a href="sign.html">SIGN-IN</a><br></div> -->
    <nav class="navbar background h-nav-resp">
        <ul class="nav-list v-class-resp">
            <div class="logo"> <img src="heart.jpg" alt="error"> </div>
            <li> <a href="#home"> home </a> </li>
            <li> <a href="#address"> address </a> </li>
            <li> <a href="#about"> about </a> </li>
            <li> <a href="#services"> services </a> </li>
            <li> <a href="#patient"> patient </a> </li>
            <li> <a href="#appointment"> appointment </a> </li>
            <li> <a href="#doctor"> doctor </a> </li>
        </ul>
        <div class="rightnav v-class-resp">
        </div>
        <div class="burger">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
    </nav>
    <section class="background firstsection" id="home">
        <div class="box-main">
            <div class="firsthalf">
                <pre class="head"> WELCOME TO <br> HEALTH CARE <br> CENTER </pre>
            </div>
</div>
    </section>
    <section class="section" id="address">
        <div class="paras">
            <p class="sectiontag text-big">AGC HEALTH CARE CENTER.<br> The center is visited by Dr. Om
                Prakash(eye specialist) ,<br> Dr.Sanjeev Kumar(throat specialist) ,<br> Dr.Parminder Singh(heart specialist) ,<br> Dr.Gurbax Singh(teeth specialist).<br> The timings of center are from Monday - Saturday : 08:30 am to 09:30pm.</p>
            <p class="sectionsubtag text-small">It is near GURUDWARA SHEDAAN SAHIB Amritsar.</p>
        </div>
        <div class="thumbnail">
            <img src="h2.jpeg" alt="error" class="image">
        </div>
    </section>
    <section class="sectionsectionleft" id="about">
        <div class="paras">
            <p class="sectiontag text-big">
                Benefits of Primary Health Care....<br>
                Increased Access to Health Services.
                Improved Quality of Care.
                Focus on Prevention.
                Early Management of Health Conditions. 
            </p>
            <p class="sectionsubtag text-small">
                What are health goals? <br>
                1.Get adequate rest daily. 
                2.Get regular physical activity. 
                3.Eat more plant based foods. 
                4.Eat more whole-grain breads and cereals. 
                5.Choose healthy fats. 
                6.Achieve/Maintain a healthy weight. 
                </p>
        </div>
        <div class="thumbnail">
            <img src="heart3.jpg" alt="error" class="image">
        </div>
    </section>
    <section class="section" id="services">
        <div class="paras">
            <p class="sectiontag text-big">HEALTH SERVICES <br>
                Mental health care<br>
                Dental care,
                Laboratory and diagnostic care,
                Substance abuse treatment,
                Preventative care,
                Physical and occupational therapy,
                Nutritional support,
                Pharmaceutical care,
                Transportation,
                Prenatal care</p>
            <p class="sectionsubtag text-small">Types of Providers:-<br>
                primary care providers,
                nurses,
                specialists ,
                pharmacists.
                <br>
                Health Care Center providers include:<br>
                medical doctors (MD), 
                doctors of osteopathic medicine (DO),
                Obstetricians/gynecologists (OB/GYN), 
                Physician assistants (PA),
                Nurse practitioners (NP)<br> 
            </p>
        <div>
        <div class="thumbnail">
            <img src="h7.jpeg" alt="error" class="image">
        </div>
    </section>
    <section class="patient" id="patient">
    <div class="carousel fade-carousel slide" data-ride="carousel" data-interval="4000" id="bs-carousel">
  <div class="overlay"></div>
  <div class="carousel-inner">
    <div class="item slides active">
      <div class="slide-1"></div>
      <div class="hero">
        <hgroup>
        <h1 class="text-advance"> PATIENT FORM </h1>
        <p><h2> ENTER PATIENT DETAILS :- </h2></p>
        <div class="form">
        <div class="container">
        <?php
        if($insert == true)
        {
        echo "<p class='submitmsg'>THANKS FOR SUBMITTING</p>";
        }
        ?>
        <form action="proj.php" method="post">
            <input type="hidden" name="action" value="save_patient" />
            <input class="form-input" type="text" name="P_id" id="P_id" placeholder="ENTER YOUR ID NUMBER"> <br>
            <input class="form-input" type="text" name="name" id="name" placeholder="ENTER Y0UR NAME"> <br>
            <input class="form-input" type="text" name="age" id="age" placeholder="ENTER YOUR AGE"> <br>
            <input class="form-input" type="text" name="gender" id="gender" placeholder="ENTER YOUR SEX"> <br>
            <input class="form-input" type="email" name="email" id="email" placeholder="ENTER YOUR EMAIL"><br>
            <input class="form-input" type="text" name="mobileno" id="mobileno" placeholder="ENTER YOUR MOBILENO"> <br>
            <button class="btn-btn"> SUBMIT </button>
        </form>
        </div>
        </div>
        </hgroup>
      </div>
    </div>
    </div>
  </div> 
</div>
    </section>
    <hr>
    <section class="appointment" id="appointment">
    <div class="carousel fade-carousel slide" data-ride="carousel" data-interval="4000" id="bs-carousel">
  <div class="overlay"></div>
  <div class="carousel-inner">
    <div class="item slides active">
      <div class="slide-1"></div>
      <div class="hero">
        <hgroup>
    <h1 class="text-advance"> APPOINTMENT FORM </h1>
    <p><h2> ENTER DETAILS :- </h2></p>
    <div class="form">
    <div class="container">
    <?php
        if($insert == true)
        {
        echo "<p class='submitmsg'>THANKS FOR SUBMITTING</p>";
        }
    ?>
         <form action="proj.php" method="post">
         <input type="hidden" name="action" value="save_appointment" />
            <input class="form-input" type="text" name="appointmentnum" id="number" placeholder="ENTER Y0UR APPOINTMENT NUMBER"> <br>
            <input class="form-input" type="text" name="P_id" id="P_id" placeholder="ENTER Y0UR P_ID"> <br>
            <input class="form-input" type="text" name="D_id" id="D_id" placeholder="ENTER D_ID"> <br>
            <input class="form-input" type="date" name="date" id="date" placeholder="ENTER APPOINTMENT DATE"> <br>
            <button class="btn-btn"> SUBMIT </button>
        </form>
    </div>
    </div>
        </hgroup>
      </div>
    </div>
    </div>
  </div> 
</div>
    </section>
    <hr>
    <section class="doctor" id="doctor">
    <div class="carousel fade-carousel slide" data-ride="carousel" data-interval="4000" id="bs-carousel">
  <div class="overlay"></div>
  <div class="carousel-inner">
    <div class="item slides active">
      <div class="slide-1"></div>
      <div class="hero">
        <hgroup>
            <h1 class="text-advance"> DOCTOR FORM </h1>
            <p><h2> ENTER DETAILS :- </h2></p>
       <?php
        if($insert == true)
        {
        echo "<p class='submitmsg'>THANKS FOR SUBMITTING</p>";
        }
       ?>
        <form action="proj.php" method="post">
        <input type="hidden" name="action" value="save_doctor" />
            <input class="form-input" type="text" name="D_id" id="D_id" placeholder="ENTER DOCTOR UNIQUE ID"> <br>
            <input class="form-input" type="text" name="D_no" id="D_no" placeholder="ENTER Doctor Number"> <br>
            <input class="form-input" type="text" name="D_name" id="D_name" placeholder="ENTER Doctor Name"> <br>
            <button class="btn-btn"> SUBMIT </button>
    </form>
    </div>
    </div>
        </hgroup>
      </div>
    </div>
    </div>
  </div> 
</div>
    </section>
    <hr>
    <footer class="background">
        <p class="text-footer">
            <!-- website by gurnoorkaur,<br>simratpalsingh,yuktikapoor,taranpreetkaur -->
            copyright:)
        </p>
    </footer>
    <script src="h.js"></script>
</body>
</html>