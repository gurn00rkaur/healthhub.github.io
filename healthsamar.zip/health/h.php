<?php
$insert = false;
if(isset($_POST['name']))
{
   // set connection variables
   $server = "localhost";
   $username = "root";
   $password = "";

   // create a database connection 
   $con = mysqli_connect($server,$username,$password);

   // check for connection success 
   if(!$con)
   {
    die("connection to this database failed due to" . mysqli_connect_error());    
   }
   // echo "success connecting to the db";

   // collect post variables 
   $P_id = $_POST['P_id'];
   $name = $_POST['name'];
   $age = $_POST['age'];
   $gender = $_POST['gender'];
   $email = $_POST['email'];
   $mobileno = $_POST['mobileno'];
   $sql = "INSERT INTO  `healthcare` . `health` (`P_id`,`name`, `age`, `gender`, `email`, `mobileno`) VALUES ('$P_id','$name', '$age', '$gender', '$email', '$mobileno');";

   // echo $sql;

   // execute the query 
   if($con->query($sql) == true)
   {
      // echo "successfully inserted";

      // flag for sucessful insertion 
      $insert = true;
   }
   else
   {
      echo "ERROR: $sql <br> $con->error";
   }

   // close tha database connection 
   $con->close();

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>website</title>
    <link rel="stylesheet" href="h.css">
    <script src="h.js"></script>
    <h1> HEALTH CARE CENTER!!! <h1>
</head>
<body>
    <header>
    <div class="log"><a href="log.html">LOG-IN</a></div>
    <div class="sig"><a href="sign.html">SIGN-IN</a><br></div>
    </header>
    <nav class="navbar background h-nav-resp">
        <ul class="nav-list v-class-resp">
            <div class="logo"> <img src="h9.jpeg" alt="error"> </div>
            <li> <a href="#information"> information </a> </li>
            <li> <a href="#address"> address </a> </li>
            <li> <a href="#about"> about </a> </li>
            <li> <a href="#services"> services </a> </li>
            <li> <a href="#contact"> contact </a> </li>
        </ul>
        <div class="rightnav v-class-resp">
            <input type="text" name="search" id="search">
            <button class="btn btn-sn"> search </button>
        </div>
        <div class="burger">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
    </nav>
    <section class="background firstsection" id="information">
        <div class="box-main">
            <div class="firsthalf">
                <p class="text-big">Health Care Center<br>
                    Health centers are community-based and patient-directed organizations that provide affordable,
                    accessible, high-quality primary health care services to individuals and families, including people
                    experiencing homelessness, agricultural workers, residents of public housing, and veterans.

                    Health centers integrate access to pharmacy, mental health, substance use disorder, and oral health
                    services in areas where economic, geographic, or cultural barriers limit access to affordable health
                    care. Health centers reduce health disparities by emphasizing coordinated care management of
                    patients with multiple health care needs and the use of key quality improvement practices, including
                    health information technology..</p>
                <p class="text-small">Healthcare is described as the identification, cure, prevention as well as
                    management of an ailment, injury, illness, and the safeguarding mental and physical well-being in
                    individuals. Healthcare services are generally offered by allied health care professionals and
                    medical practitioners.
                    Health services cover many different types of medical issues. Many people think of primary care,
                    outpatient care, and emergency care when they need an illness managed or are generally not feeling
                    well. </p>
                <div class="buttons">
                    <button class="btn">like</button>
                    <button class="btn">share</button>
                </div>

            </div>

            <div class="secondhalf">
                <img src="h1.jpeg" alt="noope">
            </div>
        </div>
    </section>
    <section class="section" id="address">
        <div class="paras">
            <p class="sectiontag text-big">AGC HEALTH CARE CENTER is in Amritsar. The center is visited by Dr. Om
                Prakash , Dr.Sanjeev Kumar. The timings of center are from Monday - Saturday : 08:30 am to 09:30pm.</p>
            <p class="sectionsubtag text-small">It is situated at CHURE BERI BAZAR , CHINT PURNI CHOWNK , BHAGTANWALA,
                Amritsar.</p>
        </div>
        <div class="thumbnail">
            <img src="h5.jpeg" alt="error" class="image">
            <!-- <script>
                $(document).ready(function () {
                    $(".image").click(function () {
                        $(".image").animate(
                            {
                                height: '50px',
                                width: '15px'
                            }
                        )
                    })
                }, 10000)
            </script> -->
        </div>
    </section>
    <section class="sectionsectionleft" id="about">
        <div class="paras">
            <p class="sectiontag text-big">
                Benefits of Primary Health Care....
                Increased Access to Health Services. ...
                Improved Quality of Care. ...
                Focus on Prevention. ...
                Early Management of Health Conditions. ...
                Characteristics of Primary Care Delivery. ...
                Reduced Need for Specialist Care. </p>
            <p class="sectionsubtag text-small">
                What are health goals?....
                1.Get adequate rest daily. ...
                2.Get regular physical activity. ...
                3.Eat more plant based foods. ...
                4.Eat more whole-grain breads and cereals. ...
                5.Choose healthy fats. ...
                6.Achieve/Maintain a healthy weight. ...
                Be free of dependence on tobacco, illicit drugs, or alcohol. ...
                8.Maintain a cheerful, hopeful outlook on life.</p>
        </div>
        <div class="thumbnail">
            <img src="h2.jpeg" alt="error" class="image">
            <!-- <script>
                $(document).ready(function () {
                    $(".image").click(function () {
                        $(".image").animate(
                            {
                                height: '50px',
                                width: '15px'
                            }
                        )
                    })
                }, 10000)
            </script> -->
        </div>
    </section>
    <section class="section" id="services">
        <div class="paras">
            <p class="sectiontag text-big">Health services cover many different types of medical issues. Many people
                think of primary care, outpatient care, and emergency care when they need an illness managed or are
                generally not feeling well. However, there are more health services that are dedicated to certain
                illnesses or issues.
                These health services include:

                Mental health care
                Dental care
                Laboratory and diagnostic care
                Substance abuse treatment
                Preventative care
                Physical and occupational therapy
                Nutritional support
                Pharmaceutical care
                Transportation
                Prenatal care</p>
            <p class="sectionsubtag text-small">Types of Providers
                There are many different types of health services providers, such as primary care providers, nurses,
                specialists, and pharmacists.

                Health Care Center providers include:

                Generalists, such as medical doctors (MD) and doctors of osteopathic medicine (DO), who focus on family
                practice, internal medicine, or pediatrics
                Obstetricians/gynecologists (OB/GYN), who focus on pregnancy, reproductive health, and prenatal care
                Physician assistants (PA), who work in a partnership with an MD or DO
                Nurse practitioners (NP), who work as health care center providers and can prescribe medication. They
                focus on reproductive health, family medicine (FNP), adult care (ANP), pediatrics (PNP), or geriatrics
                (GNP).</p>
        </div>
        <div class="thumbnail">
            <img src="h3.jpeg" alt="error" class="image">
            <!-- <script>
                $(document).ready(function () {
                    $(".image").click(function () {
                        $(".image").animate(
                            {
                                height: '50px',
                                width: '15px'
                            }
                        )
                    })
                }, 10000)
            </script> -->
        </div>
    </section>
    <section class="patient" id="patient">
        <h1 class="text-advance"> PATIENT FORM </h1>
        <p><h2> ENTER PATIENT DETAILS :- </h2></p>
        <div class="form">
        <div class="container">
        <?php
        if($insert == true)
        {
        echo "<p class='submitmsg'>THANKS FOR SUBMITTING</p>";
        }
        ?>
        <form action="h.php" method="post">
            <input class="form-input" type="text" name="P_id" id="P_id" placeholder="ENTER YOUR ID NUMBER"> <br>
            <input class="form-input" type="text" name="name" id="name" placeholder="ENTER Y0UR NAME"> <br>
            <input class="form-input" type="text" name="age" id="age" placeholder="ENTER YOUR AGE"> <br>
            <input class="form-input" type="text" name="gender" id="gender" placeholder="ENTER YOUR SEX"> <br>
            <input class="form-input" type="email" name="email" id="email" placeholder="ENTER YOUR EMAIL"><br>
            <input class="form-input" type="text" name="mobileno" id="mobileno" placeholder="ENTER YOUR MOBILENO"> <br>
            <button class="btn-btn"> SUBMIT </button>
        </form>
        </div>
        </div>
    </section>
    <hr>
    <section class="appointment" id="appointment">
    <h1 class="text-advance"> APPOINTMENT FORM </h1>
    <p><h2> ENTER DETAILS :- </h2></p>
    <div class="form">
    <div class="container">
       <?php
        if($insert == true)
        {
        echo "<p class='submitmsg'>THANKS FOR SUBMITTING</p>";
        }
       ?>
        <form action="h.php" method="post">
            <input class="form-input" type="text" name="P_id" id="P_id" placeholder="ENTER Y0UR ID"> <br>
            <input class="form-input" type="text" name="D_id" id="D_id" placeholder="ENTER D_ID"> <br>
            <input class="form-input" type="date" name="date" id="date" placeholder="ENTER APPOINTMENT DATE"> <br>
            <button class="btn-btn"> SUBMIT </button>
        </form>
    </div>
    </section>
    <hr>
    <section class="doctor" id="doctor">
    <h1 class="text-advance"> CHOOSE </h1>
    <p><h2> ENTER DETAILS :- </h2></p>
    <div class="form">
    <div class="container">
       <?php
        if($insert == true)
        {
        echo "<p class='submitmsg'>THANKS FOR SUBMITTING</p>";
        }
       ?>
        <form action="h.php" method="post">
            <input class="form-input" type="text" name="P_id" id="P_id" placeholder="ENTER Y0UR ID"> <br>
            <input class="form-input" type="text" name="D_id" id="D_id" placeholder="ENTER D_ID"> <br>
            <input type="form-input" type="checkbox" name="select doctor" id="checkbox" placeholder="SELECT DOCTOR">
            <select name="DOCTOR">
                <div>
                    <option value="select" selected="selected"></option>
                    <option value="Dr. Sanjeev Arora">Dr. Sanjeev Arora</option>
                    <option value="Dr.Om Prakash">Dr.Om Prakash</option>
            </select>
            <button class="btn-btn"> SUBMIT </button>
    </form>
    </div>
    </section>
    <hr>
    <footer class="background">
        <p class="text-footer">
            website by gurnoorkaur
        </p>
    </footer>
    <script src="h.js"></script>
</body>
</html>