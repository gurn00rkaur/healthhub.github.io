<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dctor form</title>
</head>
<body>
    <div class="carousel fade-carousel slide" data-ride="carousel" data-interval="4000" id="bs-carousel">
        <div class="overlay"></div>
        <div class="carousel-inner">
          <div class="item slides active">
            <div class="slide-1"></div>
            <div class="hero">
              <hgroup>
                  <h1 class="text-advance"> DOCTOR FORM </h1>
                  <p><h2> ENTER DETAILS :- </h2></p>
             <?php
              if($insert == true)
              {
              echo "<p class='submitmsg'>THANKS FOR SUBMITTING</p>";
              }
             ?>
              <form action="proj.php" method="post">
              <input type="hidden" name="action" value="save_doctor" />
                  <input class="form-input" type="text" name="D_id" id="D_id" placeholder="ENTER DOCTOR UNIQUE ID"> <br>
                  <input class="form-input" type="text" name="D_no" id="D_no" placeholder="ENTER Doctor Number"> <br>
                  <input class="form-input" type="text" name="D_name" id="D_name" placeholder="ENTER Doctor Name"> <br>
                  <button class="btn-btn"> SUBMIT </button>
          </form>
          </div>
          </div>
              </hgroup>
            </div>
          </div>
          </div>
        </div> 
      </div>
</body>
</html>