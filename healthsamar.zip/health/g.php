<?php
$insert = false;
if(isset($_POST['name']))
{
   // set connection variables
   $server = "localhost";
   $username = "root";
   $password = "";

   // create a database connection 
   $con = mysqli_connect($server,$username,$password);

   // check for connection success 
   if(!$con)
   {
    die("connection to this database failed due to" . mysqli_connect_error());    
   }
   // echo "success connecting to the db";

   // collect post variables 
   $name = $_POST['name'];
   $age = $_POST['age'];
   $gender = $_POST['gender'];
   $email = $_POST['email'];
   $mobileno = $_POST['mobileno'];
   $sql = "INSERT INTO  `healthcare` . `health` (`name`, `age`, `gender`, `email`, `mobileno`) VALUES ('$name', '$age', '$gender', '$email', '$mobileno');";

   // echo $sql;

   // execute the query 
   if($con->query($sql) == true)
   {
      // echo "successfully inserted";

      // flag for sucessful insertion 
      $insert = true;
   }
   else
   {
      echo "ERROR: $sql <br> $con->error";
   }

   // close tha database connection 
   $con->close();

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>website</title>
    <link rel="stylesheet" href="g.css">
    <script src="g.js"></script>
</head>
<body>
    <img class="bg" src="C:\wdxampp\htdocs\health" alt="error">
    <div class="container">
        <h1>health care center</h1>
        <p>enter details</p>
        <?php
        if($insert == true)
        {
        echo "<p class='submitmsg'>THANKS FOR SUBMITTING</p>";
        }
        ?>
        <form action="g.php" method="post">
            <input class="form-input" type="text" name="name" id="name" placeholder="ENTER Y0UR NAME"> <br>
            <input class="form-input" type="text" name="age" id="age" placeholder="ENTER YOUR AGE"> <br>
            <input class="form-input" type="text" name="gender" id="gender" placeholder="ENTER YOUR SEX"> <br>
            <input class="form-input" type="email" name="email" id="email" placeholder="ENTER YOUR EMAIL"><br>
            <input class="form-input" type="text" name="mobileno" id="mobileno" placeholdder="ENTER YOUR MOBILENO"> <br>
            <!-- <input class="form-input" type="date" name="date" id="date" placeholder="APPOINTMENT DATE"><br>
            <input type="form-input" type="checkbox" name="select doctor" id="checkbox" placeholder="SELECT DOCTOR">
            <select name="DOCTOR">
                <div>
                    <option value="select" selected="selected"></option>
                    <option value="Dr. Sanjeev Arora">Dr. Sanjeev Arora</option>
                    <option value="Dr.Om Prakash">Dr.Om Prakash</option>
            </select>
            <textarea class="form-input" name="text" id="text" cols="30" rows="10"
                placeholder="ELABORATE YOUR CONCERN"></textarea> -->
            <button class="btn-btn"> SUBMIT </button>
        </form>
    </div>
    <script src="g.js"></script>
    <!-- INSERT INTO `health` (`name`, `age`, `gender`, `email`, `mobileno`) VALUES ('GURNOOR KAUR', '20', 'Female', 'zartaj2495@gmail.com', '1264349908'); -->
    <!-- INSERT INTO `health` (`name`, `age`, `gender`, `email`, `mobileno`) VALUES ('RAVNOOR KAUR', '20', 'Female', 'rav2105377@GMAIL.COM', '123977906'); -->
</body>
</html>