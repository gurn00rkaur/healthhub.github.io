<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php
echo "<h1> started learning php finally </h1>";
echo "<br>";

$age=20;
if($age>18)
{
    echo "you can go to partyy";
}
else if($age==18)
{
    echo"yoy can";
}
else
{ 
    echo"you cant";
}


$lang = array("c","c++","python");
echo $lang[1];
echo count($lang);


$a= 0;
while($a <= 10)
{
    echo "<br> the value of a is ";
    echo $a;
    $a++;
}


$a= 0;
do
{
    echo "<br> the value of a is ";
    echo $a;
    $a++;
}while($a <= 10);


$a= 200;
for ($a=200; $a < 10; $a++) { 
    echo "<br> the value of a is:";
    echo $a;
}


foreach($lang as $value)
{
    echo "$value is";
    echo $value;
}


function print5()
{
    echo "five";
}
print5();


function print_number($number)
{
    echo "<br> your number is";
    echo $number;
}
print_number(45)


?>
</body>
</html>
